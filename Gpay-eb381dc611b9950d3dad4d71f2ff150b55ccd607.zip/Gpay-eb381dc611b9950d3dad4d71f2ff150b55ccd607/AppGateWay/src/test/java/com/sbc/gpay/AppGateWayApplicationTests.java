package com.sbc.gpay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppGateWayApplicationTests {

	@Test
	void contextLoads() {
	}

}
