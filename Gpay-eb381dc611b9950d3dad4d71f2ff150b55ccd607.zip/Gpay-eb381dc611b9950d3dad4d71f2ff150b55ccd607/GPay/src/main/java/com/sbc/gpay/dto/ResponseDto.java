package com.sbc.gpay.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResponseDto {
	
	private String statusMessage;
	private int statusCode;

}
